import numpy as np
import scipy.signal as signal

fs = 2000
f1 = 0.5
f2 = 10

b = signal.firwin(1001,[f1/fs*2,f2/fs*2],width = None, window ='hamming',pass_zero = False, )
np.savetxt("coeffbit.dat",b)
